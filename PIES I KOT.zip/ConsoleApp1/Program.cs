﻿bool t = true;
zwierzeta anim = new zwierzeta();
int liczba = 0,liczba1=0;
int ind;
while (t)
{
    string wybór;
    Console.WriteLine("MENU:");
    Console.WriteLine("1:dodaj psa");
    Console.WriteLine("2:dodaj kota");
    Console.WriteLine("3:usuń psa");
    Console.WriteLine("4:usun kota");
    Console.WriteLine("5:wyswietl psa");
    Console.WriteLine("6:wyswietl kota");
    Console.WriteLine("7:koniec");
    Console.WriteLine("wybierz opcje");
    wybór = Console.ReadLine();
    switch (wybór)
    {

        case "1":
            {
                anim.dodaj("pies", liczba);
                liczba++;
                
                break;
            }

        case "2":
            {
                anim.dodaj("kot", liczba);
                liczba++;
                break;
            }
        case "3":
            Console.WriteLine("podaj index usuniecia");
            ind= Int32.Parse(Console.ReadLine());
            anim.usuń("pies", ind);
            break;
        case "4":
            Console.WriteLine("podaj index usuniecia");
            ind = Int32.Parse(Console.ReadLine());
            anim.usuń("kot", ind);
            break;
        case "5":
        
            Console.WriteLine("podaj index wyswietlenia");
            ind = Int32.Parse(Console.ReadLine());
            anim.wyswietl("pies", ind);
            break;
        case "6":

            Console.WriteLine("podaj index wyswietlenia");
            ind = Int32.Parse(Console.ReadLine());
            anim.wyswietl("kot", ind);
            break;
        case "7":
            t = false;
            break;
        default:
            Console.WriteLine("bledny wybor");
            break;

    }
}





internal class Pies : IAnimal
{
   public  string rasa { get; set; }
   public  string zwiazekkynologiczny { get; set; }
    public void st(string nazwapupila, string imieinazwwlasciciela, int nrchipu, string rasa, string zwiazekkynologiczny)
    {
        this.nazwapupila = nazwapupila;
        this.imieinazwwlasciciela = imieinazwwlasciciela;
        this.nrchipu = nrchipu;
        this.rasa = rasa;
        this.zwiazekkynologiczny = zwiazekkynologiczny;


    }
public void wypisz()
    {
        Console.WriteLine("nazwa pupila:");
        Console.WriteLine(this.nazwapupila);
        Console.WriteLine("imie i nazwisko własciciiela");
        Console.WriteLine(this.imieinazwwlasciciela);
        Console.WriteLine("nr chipu:");
        Console.WriteLine(this.nrchipu);
        Console.WriteLine("rasa:");
        Console.WriteLine(this.rasa);
        Console.WriteLine("zwiazek kynologiczny:");
        Console.WriteLine(this.zwiazekkynologiczny);
    }
}

abstract class IAnimal
{
    public string nazwapupila { get; set; }
    public string imieinazwwlasciciela { get; set; }
    public int nrchipu { get; set; }

    public void st(string nazwapupila1, string imieinazwwlasciciela1, int nrchipu1)
    {
        nazwapupila = nazwapupila1;
        imieinazwwlasciciela = imieinazwwlasciciela1;
        nrchipu = nrchipu1;



    }
   public void wypisz()
    {
        Console.WriteLine("nazwa pupila:");
        Console.WriteLine(this.nazwapupila);
        Console.WriteLine("imie i nazwisko własciciiela");
        Console.WriteLine(this.imieinazwwlasciciela);
        Console.WriteLine("nr chipu:");
        Console.WriteLine(this.nrchipu);


    }
}














internal class kot : IAnimal
{
    string namaszczenie;


    public void stworz(string nazwapupila, string imieinazwwlasciciela, int nrchipu, string namaszczenie)
    {
        this.nazwapupila = nazwapupila;
        this.imieinazwwlasciciela = imieinazwwlasciciela;
        this.nrchipu = nrchipu;
        this.namaszczenie = namaszczenie;


    }
    public void wypisz()
    {
        Console.WriteLine("nazwa pupila:");
        Console.WriteLine(this.nazwapupila);
        Console.WriteLine("imie i nazwisko własciciiela");
        Console.WriteLine(this.imieinazwwlasciciela);
        Console.WriteLine("nr chipu:");
        Console.WriteLine(this.nrchipu);
        Console.WriteLine("namaszczenie:");
        Console.WriteLine(this.namaszczenie);
    }
}
public class zwierzeta
{
    List<kot> kots=new List<kot>();
     List<Pies> dogs = new List<Pies>();


   public void dodaj(string rodzaj, int nrchipu)
    {
        string nazw;
        string imieinazwwlasciciela;
        Console.WriteLine("podaj nazwe pupila");
        nazw = Console.ReadLine();
        Console.WriteLine("podaj nazwe wlasciciela");
        imieinazwwlasciciela = Console.ReadLine();



        if (rodzaj == "kot")
        {
            Console.WriteLine("podaj namaszczenbie");
            string namaszczenie = Console.ReadLine();
            kot cat = new kot();
            cat.stworz(nazw, imieinazwwlasciciela, nrchipu, namaszczenie);
            kots.Add(cat);
            
        }
        else
        {
            Console.WriteLine("podaj rase");
            string rasa = Console.ReadLine();
            Console.WriteLine("podaj zwiazek kynologiczny");
            string zwiazekkynologiczny = Console.ReadLine();
            Pies dog = new Pies();
            dog.st(nazw, imieinazwwlasciciela, nrchipu, rasa, zwiazekkynologiczny);
          
            this.dogs.Add(dog);
           
        }
    }
    public void usuń(string rodzaj, int index)
    {

        if (rodzaj == "kot")
        {
            if (index > 0 && kots.Count > index)
            {
                kots.RemoveAt(index);
                Console.WriteLine("usunięto pomyślnie");
            }
            else
                Console.WriteLine("nie ma takiego indexu");

        }
        else
        {
            if (index > 0 && dogs.Count > index)
            {
                dogs.RemoveAt(index);
                Console.WriteLine("usunięto pomyślnie");
            }
            else
                Console.WriteLine("nie ma takiego indexu");

        }
    }
    public void wyswietl(string rodzaj, int index)
    {

        if (rodzaj == "kot")
        { if (index > 0 && kots.Count > index)
                this.kots[index].wypisz();
            else
                Console.WriteLine("nie ma takiego indexu");
            
        }
        else
        {
            if (index > 0 && dogs.Count > index)
                this.dogs[index].wypisz();
            else
                Console.WriteLine("nie ma takiego indexu");

        }
    }

}

